<h1 align="center">YANG: Yet Another Nitro Generator</h1>

<p align="center">
  <a href="https://github.com/Tenclea/YANG/"><img src="https://img.shields.io/github/last-commit/tenclea/yang?style=flat" /></a>
  <a href="https://github.com/Tenclea/YANG/stargazers"><img src="https://img.shields.io/github/stars/Tenclea/YANG?style=flat" /></a>
  <a href="https://github.com/Tenclea/YANG"><img src="https://visitor-badge.laobi.icu/badge?page_id=tenclea.YANG" /></a>
 
  <br>
  <b>The most efficient nitro generator and checker you'll ever find.</b><br>
  Made with ❤ by <b><a href="https://github.com/tenclea">Tenclea</a></b>
  <br>
  If you liked this project, please consider <b>starring</b> it :)
</p>

<h2 align="center">Previews</h2>

<p align="center">
   • Proxy Scrapper & Checker : <br>
   <img src="https://i.imgur.com/PQElB3e.png" title="YANG - By Tenclea : Proxy Scrapper & Checker"/>
   <br><br>
   • Main Nitro Codes Generator : <br>
   <img src="https://i.imgur.com/4QlDMU9.png" title="YANG - By Tenclea : Main Nitro Codes Generator"/>
</p>

## Main features

* **Very fast code generator and checker (2000 attempts/minute)**
* Fully automated, can generate and check codes infinitely, no need to restart every hour
* Proxy scrapper and checker
* Automatically redeems nitro
* Download fresh proxies while checking codes
* Full webhook support
* Real-time stats

## Requirements

* [Node.js v16+](https://nodejs.org/en/) (not needed with the compiled version)
* [A Discord token](https://github.com/Tyrrrz/DiscordChatExporter/wiki/Obtaining-Token-and-Channel-IDs#how-to-get-a-user-token) (optional)

## Setup

* Clone this repository to your computer or download a compiled release from the [release page](https://github.com/Tenclea/YANG/releases).
* Edit the config variables in the `config.yml` file as you like.
* Paste fresh http(s)/socks proxies into `required/http-proxies.txt`/`required/socks-proxies.txt`.
* Open up a command prompt in the downloaded folder and type `npm install` to install the requirements (not required for the compiled version).
* Start the generator by typing `node app.js`, or opening up the executable you downloaded !

## Disclaimer

Everything you can see here has been made for educational purposes and as a proof of concept.  
I do not promote the usage of my tools, and do not take responsibility for any bad usage of this tool.  
Stealing codes means stealing money from people and is against Discord's TOS. Don't.
